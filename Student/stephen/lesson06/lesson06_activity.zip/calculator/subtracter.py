"""
This module provides the subtraction operation
"""


class Subtracter(object):
    """
    Class for subtraction
    """
    @staticmethod
    def calc(operand_1, operand_2):
        """
        Method defining subtraction operation
        """
        return operand_1 - operand_2
