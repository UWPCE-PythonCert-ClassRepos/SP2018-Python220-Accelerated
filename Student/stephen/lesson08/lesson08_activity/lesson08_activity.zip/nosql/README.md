
[On GitLab now (no more updates here)](https://gitlab.com/uw-pyclass/nosql)

# nosql

python certificate nosql example

All of the Python code is in the src directory.
